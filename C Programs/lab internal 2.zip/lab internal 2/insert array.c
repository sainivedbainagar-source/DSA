#include<stdio.h>
#define m 100
int main(){
int n, pos,a[m],i,x;
printf("enter array size\n");
    scanf("%d", &n);
    printf("enter elements");
    for(i= 0; i<n;i++  ){
        scanf("%d", &a[i]);
    }
for(i= 0; i<n;i++  ){
        printf("%d ", a[i]);
    }

    printf("enter position\n");
    scanf("%d",&pos);
    printf("enter element\n");
    scanf("%d",&x);
if (pos < 0 || pos >n || n>=m)
    printf("invalid operation\n");
    return 1;
else {
    for(i =n; i>pos;i++){
        a[i]= a[i-1];
    }
    a[pos]= x;
    n++;
}
    for(i= 0; i<n;i++  ){
        printf("%d ", a[i]);
    }
    return 0;


}

