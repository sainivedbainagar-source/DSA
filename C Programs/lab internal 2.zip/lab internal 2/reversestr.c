#include <stdio.h>

int main() {
    char s1[100], temp;
    int i = 0, j;

    printf("Enter a string\n");
    gets(s1);

    /* Find the last index using your logic */
    while (s1[i] != '\0') {
        i++;
    }

    j = i - 1;   // last character index
    i = 0;       // start index

    /* Reverse the string */
    while (i < j) {
        temp = s1[i];
        s1[i] = s1[j];
        s1[j] = temp;
        i++;
        j--;
    }

    printf("Reversed string: %s\n", s1);

    return 0;
}

